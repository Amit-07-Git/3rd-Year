from decimal import Decimal


class CommissionEmployee:
    # constructor to initialise attributes. All attributes are private but not hidden
    def __init__(self, first_name, last_name, aadhaar_id, gross_sales, commission_rate):
        self._first_name = first_name
        self._last_name = last_name
        self._aadhaar_id = aadhaar_id
        self._gross_sales = gross_sales  # property
        self._commission_rate = commission_rate  # property

    # Set properties to fetch and modfiy private attributes as needed.
    @property
    def first_name(self): return self._first_name

    @property
    def last_name(self): return self._last_name

    @property
    def aadhaar_id(self): return self._aadhaar_id

    @property
    def gross_sales(self): return self._gross_sales

    @gross_sales.setter
    def gross_sales(self, sales):
        if sales < Decimal('0.00'):
            raise ValueError('Value must be >= 0.00')

        self._gross_sales = sales

    @property
    def commission_rate(self):
        return self._commission_rate

    @commission_rate.setter
    def commission_rate(self, rate):
        if not (Decimal('0.00') < rate <= Decimal('1.0')):
            raise ValueError('Rate must be between 0 and 1')

        self._commission_rate = rate

    def earnings(self):
        return self._gross_sales * self._commission_rate

    def __repr__(self):
        return (
            f'Commission Employee: \nName : {self.first_name} {self.last_name}\nAadhaar : {self.aadhaar_id}\nGross Sales : {self.gross_sales:.2f}\nCommission Rate : {self.commission_rate:.2f}'
        )
