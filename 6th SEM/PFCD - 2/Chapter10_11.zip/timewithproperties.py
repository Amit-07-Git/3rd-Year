class Time:
    def __init__(self, hours=0, minutes=0, seconds=0):
        self._hours = hours
        self._minutes = minutes
        self._seconds = seconds

    @property
    def hours(self): return self._hours

    @hours.setter
    def hours(self, hour):
        if not (0 <= hour < 24):
            raise ValueError('Set a value between 0-23')

        self._hours = hour

    @property
    def minutes(self): return self._minutes

    @minutes.setter
    def minutes(self, minute):
        if not (0 <= minute < 60):
            raise ValueError('Set a value between 0-59')

        self._minutes = minute

    @property
    def seconds(self): return self._seconds

    @seconds.setter
    def seconds(self, second):
        if not (0 <= second < 60):
            raise ValueError('Set a value between 0-59')

        self._seconds = second

    def __str__(self):
        return f'Time is {self.hours} hour(s) {self.minutes} minute(s) {self.seconds} second(s)'

    def __repr__(self):
        return f'Time(hour(s)={self.hours} minute(s)={self.minutes} second(s)={self.seconds})'
